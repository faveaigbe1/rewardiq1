# RewardIQ Mobile App

## Setup

```bash
# Install dependencies
npm install

# Start development server
npx expo start

# Run on specific platform
npx expo start --ios
npx expo start --android
```

## Before running

1. Update `app/_layout.tsx` — replace `pk_test_your_stripe_publishable_key` with your real Stripe publishable key
2. The Supabase keys are already configured in `lib/supabase.ts`
3. The Apps Script URL is already configured in `lib/constants.ts`

## Build for stores

```bash
# Install EAS CLI
npm install -g eas-cli

# Login to Expo
eas login

# Configure project
eas build:configure

# Build for iOS (requires Apple Developer account)
eas build --platform ios

# Build for Android
eas build --platform android
```

## Project structure

```
app/
  (auth)/         Login screen
  (tabs)/
    analysis/     Analysis form → Teaser → Psycho → Results
    trips/        Trip request form
    dashboard/    User dashboard
    account/      Account settings
  contractor/     Contractor portal
  admin/          Admin dashboard
components/
  ui.tsx          Shared UI components
lib/
  supabase.ts     Supabase client
  api.ts          Apps Script API calls
  constants.ts    App constants
  store.ts        Zustand state
```

## Architecture

- **Frontend**: React Native + Expo Router
- **Auth**: Supabase magic links
- **Database**: Supabase (same schema as web app)
- **Backend**: Google Apps Script (same as web app)
- **Payments**: Stripe (opens in browser)
- **State**: Zustand
