import { useEffect, useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, TextInput, RefreshControl } from 'react-native';
import { router } from 'expo-router';
import { supabase } from '@/lib/supabase';
import { api } from '@/lib/api';
import { C, Card, Button, LoadingScreen, StatCard } from '@/components/ui';
import { ADMIN_EMAIL, SEGMENT_COLORS } from '@/lib/constants';

type Tab = 'users'|'analyses'|'trips'|'bookings'|'intakes';

export default function AdminScreen() {
  const [authed, setAuthed]     = useState(false);
  const [loading, setLoading]   = useState(true);
  const [data, setData]         = useState<any>({ users:[], analyses:[], trips:[], bookings:[], intakes:[] });
  const [tab, setTab]           = useState<Tab>('users');
  const [search, setSearch]     = useState('');
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session || session.user.email !== ADMIN_EMAIL) {
        router.replace('/(auth)/login'); return;
      }
      setAuthed(true);
      loadData();
    });
  }, []);

  async function loadData() {
    try {
      const d = await api.adminData();
      setData(d);
    } catch(e) { console.log(e); }
    finally { setLoading(false); setRefreshing(false); }
  }

  if (loading || !authed) return <LoadingScreen message="Loading admin..." />;

  const tabs: Tab[] = ['users','analyses','trips','bookings','intakes'];

  function filterData(arr: any[]) {
    if (!search) return arr;
    const q = search.toLowerCase();
    return arr.filter((r: any) => JSON.stringify(r).toLowerCase().includes(q));
  }

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>Admin Dashboard</Text>
          <Text style={styles.headerSub}>{ADMIN_EMAIL}</Text>
        </View>
        <Button label="← Back" onPress={() => router.back()} variant="outline" style={{ paddingVertical: 7 }} />
      </View>

      {/* Stats */}
      <View style={styles.statsRow}>
        <StatCard label="Users" value={String(data.users.length)} />
        <StatCard label="Paid" value={String(data.analyses.filter((a:any) => a.paid).length)} green />
        <StatCard label="Trips" value={String(data.trips.length)} />
        <StatCard label="Open" value={String(data.trips.filter((t:any) => t.status==='OPEN').length)} />
        <StatCard label="Sessions" value={String(data.bookings.length)} />
      </View>

      {/* Search */}
      <View style={styles.searchWrap}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search all records..."
          placeholderTextColor={C.textHint}
          value={search}
          onChangeText={setSearch}
          autoCapitalize="none"
        />
      </View>

      {/* Tabs */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabsWrap}>
        {tabs.map(t => (
          <TouchableOpacity key={t} style={[styles.tab, tab === t && styles.tabActive]} onPress={() => setTab(t)}>
            <Text style={[styles.tabText, tab === t && styles.tabTextActive]}>{t.charAt(0).toUpperCase() + t.slice(1)}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <ScrollView
        contentContainerStyle={{ padding: 14, paddingBottom: 40 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadData(); }} tintColor={C.teal} />}
      >
        {tab === 'users' && filterData(data.users).map((u: any) => (
          <Card key={u.id}>
            <View style={styles.recordRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.recordMain}>{u.email}</Text>
                <Text style={styles.recordSub}>{u.name || '—'} · {new Date(u.created_at).toLocaleDateString()}</Text>
              </View>
              {u.segment && (
                <View style={[styles.segBadge, { backgroundColor: (SEGMENT_COLORS[u.segment]?.bg || C.bgSurface) }]}>
                  <Text style={[styles.segText, { color: SEGMENT_COLORS[u.segment]?.text || C.textMuted }]}>{u.segment}</Text>
                </View>
              )}
            </View>
          </Card>
        ))}

        {tab === 'analyses' && filterData(data.analyses).map((a: any) => (
          <Card key={a.id}>
            <View style={styles.recordRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.recordMain}>{a.email}</Text>
                <Text style={styles.recordSub}>{a.top_card_name || '—'} · {new Date(a.created_at).toLocaleDateString()}</Text>
              </View>
              <View style={{ alignItems: 'flex-end', gap: 4 }}>
                <Text style={styles.gapVal}>${(a.gap||0).toLocaleString()}</Text>
                <View style={[styles.paidBadge, { backgroundColor: a.paid ? C.greenLight : C.bgSurface }]}>
                  <Text style={[styles.paidText, { color: a.paid ? C.greenText : C.textHint }]}>{a.paid ? 'Paid' : 'Free'}</Text>
                </View>
              </View>
            </View>
          </Card>
        ))}

        {tab === 'trips' && filterData(data.trips).map((t: any) => (
          <Card key={t.id}>
            <View style={styles.recordRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.recordMain}>{t.origin} → {t.destination}</Text>
                <Text style={styles.recordSub}>{t.email} · {t.cabin?.replace('_',' ')} · {t.depart_date}</Text>
                <Text style={[styles.recordSub, { fontFamily: 'monospace' }]}>{t.request_id}</Text>
              </View>
              <View style={[styles.statusBadge, { backgroundColor: getStatusBg(t.status) }]}>
                <Text style={[styles.statusText, { color: getStatusFg(t.status) }]}>{t.status}</Text>
              </View>
            </View>
            {t.claimed_by && <Text style={styles.claimedBy}>Contractor: {t.claimed_by}</Text>}
          </Card>
        ))}

        {tab === 'bookings' && filterData(data.bookings).map((b: any) => (
          <Card key={b.id}>
            <Text style={styles.recordMain}>{b.name || b.email}</Text>
            <Text style={styles.recordSub}>{b.email} · {b.tier}</Text>
            <Text style={styles.recordSub}>{b.call_date ? new Date(b.call_date).toLocaleDateString() : 'TBC'}</Text>
          </Card>
        ))}

        {tab === 'intakes' && filterData(data.intakes).map((i: any) => (
          <Card key={i.id}>
            <Text style={styles.recordMain}>{i.name || i.email}</Text>
            <Text style={styles.recordSub}>{i.email} · {i.company}</Text>
            <Text style={styles.recordSub}>Call: {i.call_date || '—'}</Text>
            {i.biggest_frustration && (
              <Text style={styles.frustration} numberOfLines={2}>{i.biggest_frustration}</Text>
            )}
          </Card>
        ))}

        {filterData(data[tab] || []).length === 0 && (
          <View style={styles.empty}>
            <Text style={styles.emptyText}>No {tab} found{search ? ` matching "${search}"` : ' yet'}</Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

function getStatusBg(s: string) {
  const m: Record<string,string> = { OPEN:'#FEF3C7', CLAIMED:C.tealLight, SUBMITTED:'#EDE9FE', QA:'#DBEAFE', SENT:C.greenLight, PAID:C.greenLight };
  return m[s] || C.bgSurface;
}
function getStatusFg(s: string) {
  const m: Record<string,string> = { OPEN:'#92400E', CLAIMED:C.tealDark, SUBMITTED:'#5B21B6', QA:'#1E40AF', SENT:C.greenText, PAID:C.greenText };
  return m[s] || C.textMuted;
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 56, paddingHorizontal: 16, paddingBottom: 14, backgroundColor: '#1a1a1a' },
  headerTitle: { fontSize: 18, fontWeight: '600', color: '#fff' },
  headerSub: { fontSize: 12, color: 'rgba(255,255,255,0.5)', marginTop: 1 },
  statsRow: { flexDirection: 'row', gap: 6, padding: 10, backgroundColor: C.bgCard, borderBottomWidth: 0.5, borderBottomColor: C.border },
  searchWrap: { padding: 10, backgroundColor: C.bgCard, borderBottomWidth: 0.5, borderBottomColor: C.border },
  searchInput: { backgroundColor: C.bg, borderWidth: 0.5, borderColor: C.borderStrong, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8, fontSize: 13, color: C.text },
  tabsWrap: { backgroundColor: C.bgCard, borderBottomWidth: 0.5, borderBottomColor: C.border, maxHeight: 44 },
  tab: { paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabActive: { borderBottomColor: C.teal },
  tabText: { fontSize: 13, color: C.textMuted },
  tabTextActive: { color: C.tealDark, fontWeight: '500' },
  recordRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10 },
  recordMain: { fontSize: 14, fontWeight: '500', color: C.text },
  recordSub: { fontSize: 12, color: C.textMuted, marginTop: 2 },
  segBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 100 },
  segText: { fontSize: 11, fontWeight: '600' },
  gapVal: { fontSize: 16, fontWeight: '700', color: C.tealDark },
  paidBadge: { paddingHorizontal: 7, paddingVertical: 2, borderRadius: 100 },
  paidText: { fontSize: 11, fontWeight: '500' },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 100 },
  statusText: { fontSize: 11, fontWeight: '500' },
  claimedBy: { fontSize: 12, color: C.textMuted, marginTop: 6 },
  frustration: { fontSize: 12, color: C.textMuted, marginTop: 6, fontStyle: 'italic', lineHeight: 17 },
  empty: { alignItems: 'center', padding: 32 },
  emptyText: { fontSize: 14, color: C.textHint },
});
