import { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  KeyboardAvoidingView, Platform, ScrollView,
  StyleSheet, Alert
} from 'react-native';
import { supabase } from '@/lib/supabase';
import { C } from '@/components/ui';

export default function LoginScreen() {
  const [email, setEmail]     = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent]       = useState(false);

  async function sendLink() {
    if (!email || !email.includes('@')) {
      Alert.alert('Invalid email', 'Please enter a valid email address.');
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: { emailRedirectTo: 'rewardiq://login-callback' }
    });
    setLoading(false);
    if (error) {
      Alert.alert('Error', error.message);
    } else {
      setSent(true);
    }
  }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        <View style={styles.header}>
          <Text style={styles.logo}>Reward<Text style={styles.logoAccent}>IQ</Text></Text>
          <Text style={styles.tagline}>Business card rewards optimizer</Text>
        </View>

        {!sent ? (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Sign in</Text>
            <Text style={styles.cardSub}>Enter your email to receive a secure login link. No password needed.</Text>
            <Text style={styles.label}>Email address</Text>
            <TextInput
              style={styles.input}
              placeholder="you@company.com"
              placeholderTextColor={C.textHint}
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              autoCorrect={false}
              onSubmitEditing={sendLink}
            />
            <TouchableOpacity
              style={[styles.btn, loading && styles.btnDisabled]}
              onPress={sendLink}
              disabled={loading}
              activeOpacity={0.8}
            >
              <Text style={styles.btnText}>{loading ? 'Sending...' : 'Send login link'}</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.card}>
            <Text style={styles.sentIcon}>📬</Text>
            <Text style={styles.cardTitle}>Check your inbox</Text>
            <Text style={styles.cardSub}>
              We sent a secure login link to{'\n'}<Text style={{ fontWeight: '600' }}>{email}</Text>.{'\n\n'}
              Tap the link in your email to sign in. It expires in 10 minutes.
            </Text>
            <TouchableOpacity onPress={() => setSent(false)}>
              <Text style={styles.linkText}>Use a different email</Text>
            </TouchableOpacity>
          </View>
        )}

        <Text style={styles.disclaimer}>
          RewardIQ · Free card optimization analysis for business owners
        </Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  scroll: { flexGrow: 1, justifyContent: 'center', padding: 24 },
  header: { alignItems: 'center', marginBottom: 32 },
  logo: { fontSize: 36, fontWeight: '700', color: C.text, letterSpacing: -1 },
  logoAccent: { color: C.teal },
  tagline: { fontSize: 14, color: C.textMuted, marginTop: 4 },
  card: {
    backgroundColor: C.bgCard,
    borderRadius: 16,
    padding: 24,
    borderWidth: 0.5,
    borderColor: C.border,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 12,
    elevation: 3,
  },
  cardTitle: { fontSize: 20, fontWeight: '600', color: C.text, marginBottom: 8 },
  cardSub: { fontSize: 14, color: C.textMuted, lineHeight: 20, marginBottom: 20 },
  label: { fontSize: 13, fontWeight: '500', color: C.text, marginBottom: 6 },
  input: {
    backgroundColor: C.bg,
    borderWidth: 0.5,
    borderColor: C.borderStrong,
    borderRadius: 8,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 14,
    color: C.text,
    marginBottom: 16,
  },
  btn: {
    backgroundColor: C.teal,
    borderRadius: 8,
    paddingVertical: 14,
    alignItems: 'center',
  },
  btnDisabled: { opacity: 0.6 },
  btnText: { color: '#fff', fontSize: 15, fontWeight: '500' },
  sentIcon: { fontSize: 40, textAlign: 'center', marginBottom: 12 },
  linkText: { color: C.teal, fontSize: 13, textAlign: 'center', marginTop: 16 },
  disclaimer: { fontSize: 11, color: C.textHint, textAlign: 'center', marginTop: 24 },
});
