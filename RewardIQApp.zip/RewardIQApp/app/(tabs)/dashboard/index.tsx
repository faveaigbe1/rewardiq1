import { useEffect, useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, RefreshControl } from 'react-native';
import { router } from 'expo-router';
import { supabase } from '@/lib/supabase';
import { C, Card, SectionTitle, StatCard, EmptyState, Badge, LoadingScreen } from '@/components/ui';
import { SEGMENT_COLORS, BOOKING_URL } from '@/lib/constants';
import { Linking } from 'react-native';

export default function DashboardScreen() {
  const [user, setUser]           = useState<any>(null);
  const [userData, setUserData]   = useState<any>(null);
  const [analyses, setAnalyses]   = useState<any[]>([]);
  const [trips, setTrips]         = useState<any[]>([]);
  const [bookings, setBookings]   = useState<any[]>([]);
  const [loading, setLoading]     = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) { router.replace('/(auth)/login'); return; }

    const email = session.user.email!;
    setUser(session.user);

    const [aRes, tRes, bRes, uRes] = await Promise.all([
      supabase.from('analyses').select('*').eq('email', email).order('created_at', { ascending: false }),
      supabase.from('trips').select('*').eq('email', email).order('created_at', { ascending: false }),
      supabase.from('bookings').select('*').eq('email', email).order('created_at', { ascending: false }),
      supabase.from('users').select('*').eq('email', email).single(),
    ]);

    setAnalyses(aRes.data || []);
    setTrips(tRes.data || []);
    setBookings(bRes.data || []);
    setUserData(uRes.data);
    setLoading(false);
    setRefreshing(false);
  }

  if (loading) return <LoadingScreen message="Loading your dashboard..." />;

  const maxGap    = analyses.length ? Math.max(...analyses.map((a: any) => a.gap || 0)) : 0;
  const firstName = (user?.user_metadata?.name || user?.email || '').split(/[\s@]/)[0];
  const segment   = userData?.segment;
  const segColors = segment ? SEGMENT_COLORS[segment] : null;

  const tripStatusColor: Record<string,string> = {
    OPEN: '#FAC775', CLAIMED: C.tealMid, SUBMITTED: '#C4B5FD',
    QA: '#93C5FD', SENT: '#86EFAC', PAID: '#4ADE80'
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.scroll}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadData(); }} tintColor={C.teal} />}
    >
      {/* Profile */}
      <View style={styles.profileCard}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>{firstName[0]?.toUpperCase()}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.profileName}>{user?.user_metadata?.name || firstName}</Text>
          <Text style={styles.profileEmail}>{user?.email}</Text>
          {segment && segColors && (
            <View style={[styles.segBadge, { backgroundColor: segColors.bg }]}>
              <Text style={[styles.segBadgeText, { color: segColors.text }]}>{segment}</Text>
            </View>
          )}
        </View>
      </View>

      {/* Stats */}
      <View style={styles.statsRow}>
        <StatCard label="Gap found" value={maxGap ? `$${maxGap.toLocaleString()}` : '—'} green />
        <StatCard label="Analyses" value={String(analyses.length)} />
        <StatCard label="Trips" value={String(trips.length)} />
        <StatCard label="Bookings" value={String(bookings.length)} />
      </View>

      {/* Analyses */}
      <SectionTitle>Your analyses</SectionTitle>
      {!analyses.length ? (
        <EmptyState icon="📊" title="No analyses yet" subtitle="Run your free analysis to see your rewards gap." action="Run free analysis" onAction={() => router.push('/(tabs)/analysis')} />
      ) : (
        analyses.map((a: any, i: number) => (
          <Card key={a.id} style={i === 0 && styles.featuredCard}>
            <View style={styles.analysisRow}>
              <View>
                <Text style={styles.analysisGapLabel}>Annual gap</Text>
                <Text style={styles.analysisGap}>${(a.gap || 0).toLocaleString()}</Text>
                <Text style={styles.analysisCardName}>{a.top_card_name || '—'}</Text>
                <Text style={styles.analysisMeta}>${(a.current_value||0).toLocaleString()} → ${(a.optimized_value||0).toLocaleString()}/yr</Text>
              </View>
              <View style={{ alignItems: 'flex-end', gap: 6 }}>
                <Text style={styles.analysisDate}>{new Date(a.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</Text>
                <View style={[styles.paidBadge, { backgroundColor: a.paid ? C.greenLight : C.bgSurface }]}>
                  <Text style={[styles.paidBadgeText, { color: a.paid ? C.greenText : C.textHint }]}>{a.paid ? 'Paid' : 'Free preview'}</Text>
                </View>
              </View>
            </View>
          </Card>
        ))
      )}

      {/* Trips */}
      <SectionTitle>Trip requests</SectionTitle>
      {!trips.length ? (
        <EmptyState icon="✈️" title="No trip requests yet" subtitle="Submit a trip and we'll find your best award redemption." action="New trip request" onAction={() => router.push('/(tabs)/trips')} />
      ) : (
        trips.map((t: any) => (
          <Card key={t.id}>
            <View style={styles.tripRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.tripRoute}>{t.origin} → {t.destination}</Text>
                <Text style={styles.tripMeta}>{t.depart_date} · {t.cabin?.replace('_',' ')} · {t.passengers} pax</Text>
                <Text style={styles.tripId}>{t.request_id}</Text>
              </View>
              <View style={[styles.tripStatus, { backgroundColor: tripStatusColor[t.status] + '30', borderColor: tripStatusColor[t.status] }]}>
                <Text style={[styles.tripStatusText, { color: tripStatusColor[t.status] }]}>{t.status}</Text>
              </View>
            </View>
            {t.status === 'SENT' && (
              <View style={styles.sentNotice}>
                <Text style={styles.sentNoticeText}>Your award options have been sent — check your email for findings + payment link.</Text>
              </View>
            )}
          </Card>
        ))
      )}

      {/* Bookings */}
      <SectionTitle>Consulting sessions</SectionTitle>
      {!bookings.length ? (
        <EmptyState icon="📅" title="No sessions booked yet" subtitle="Book a 30-minute strategy session to implement your card stack." action="Book a session" onAction={() => Linking.openURL(BOOKING_URL)} />
      ) : (
        bookings.map((b: any) => (
          <Card key={b.id} style={styles.bookingRow}>
            <View>
              <Text style={styles.bookingTier}>{b.tier || 'Consulting session'}</Text>
              <Text style={styles.bookingDate}>{b.call_date ? new Date(b.call_date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' }) : 'Date TBC'}</Text>
            </View>
            <View style={styles.confirmedBadge}>
              <Text style={styles.confirmedText}>{b.status || 'Confirmed'}</Text>
            </View>
          </Card>
        ))
      )}

      <Text style={styles.disclaimer}>
        Your data is stored securely and never shared with third parties. RewardIQ · Not financial advice.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  scroll: { padding: 16, paddingTop: 56, paddingBottom: 40 },
  profileCard: { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: C.bgCard, borderRadius: 16, padding: 16, marginBottom: 16, borderWidth: 0.5, borderColor: C.border },
  avatar: { width: 52, height: 52, borderRadius: 26, backgroundColor: C.tealLight, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 20, fontWeight: '700', color: C.tealDark },
  profileName: { fontSize: 17, fontWeight: '500', color: C.text },
  profileEmail: { fontSize: 12, color: C.textMuted, marginTop: 1 },
  segBadge: { alignSelf: 'flex-start', marginTop: 6, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 100 },
  segBadgeText: { fontSize: 11, fontWeight: '600' },
  statsRow: { flexDirection: 'row', gap: 8, marginBottom: 20 },
  featuredCard: { borderWidth: 1.5, borderColor: C.teal },
  analysisRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  analysisGapLabel: { fontSize: 11, color: C.textHint, textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 2 },
  analysisGap: { fontSize: 28, fontWeight: '700', color: C.tealDarker, letterSpacing: -0.5 },
  analysisCardName: { fontSize: 13, fontWeight: '500', color: C.text, marginTop: 4 },
  analysisMeta: { fontSize: 12, color: C.textMuted, marginTop: 2 },
  analysisDate: { fontSize: 11, color: C.textHint },
  paidBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 100 },
  paidBadgeText: { fontSize: 11, fontWeight: '500' },
  tripRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10 },
  tripRoute: { fontSize: 15, fontWeight: '600', color: C.text },
  tripMeta: { fontSize: 12, color: C.textMuted, marginTop: 2 },
  tripId: { fontSize: 11, color: C.textHint, marginTop: 2, fontFamily: 'monospace' },
  tripStatus: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 100, borderWidth: 0.5 },
  tripStatusText: { fontSize: 11, fontWeight: '500' },
  sentNotice: { backgroundColor: C.tealLight, borderRadius: 8, padding: 10, marginTop: 10 },
  sentNoticeText: { fontSize: 12, color: C.tealDark, lineHeight: 17 },
  bookingRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  bookingTier: { fontSize: 15, fontWeight: '500', color: C.text },
  bookingDate: { fontSize: 12, color: C.textMuted, marginTop: 2 },
  confirmedBadge: { backgroundColor: C.tealLight, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 100 },
  confirmedText: { fontSize: 11, color: C.tealDark, fontWeight: '500' },
  disclaimer: { fontSize: 11, color: C.textHint, textAlign: 'center', lineHeight: 16, marginTop: 8, padding: 12, backgroundColor: C.bgSurface, borderRadius: 8 },
});
