import { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  TextInput, StyleSheet, Alert
} from 'react-native';
import { router } from 'expo-router';
import { api } from '@/lib/api';
import { C, Card, Button, SectionTitle, Input, ErrorBanner } from '@/components/ui';

const CABIN_OPTIONS = [
  { value: 'economy',         label: 'Economy',        icon: '💺' },
  { value: 'premium_economy', label: 'Premium Econ',   icon: '🪑' },
  { value: 'business',        label: 'Business',       icon: '🛋️' },
  { value: 'first',           label: 'First Class',    icon: '👑' },
];
const POINTS_OPTIONS = [
  { value: 'chase',     label: 'Chase UR',    icon: '🔵' },
  { value: 'amex',      label: 'Amex MR',     icon: '🟡' },
  { value: 'capital_one',label: 'Capital One',icon: '🔴' },
  { value: 'citi',      label: 'Citi TYP',    icon: '🔷' },
  { value: 'hyatt',     label: 'Hyatt',       icon: '⬛' },
  { value: 'marriott',  label: 'Marriott',    icon: '🟠' },
  { value: 'delta',     label: 'Delta',       icon: '🟣' },
  { value: 'united',    label: 'United',      icon: '⚫' },
  { value: 'aa',        label: 'AA Miles',    icon: '🔵' },
  { value: 'other',     label: 'Other',       icon: '➕' },
];
const PRIORITY_OPTIONS = [
  { value: 'luxury',       label: 'Luxury — best product',     icon: '✨' },
  { value: 'affordability', label: 'Affordability — least pts', icon: '💰' },
  { value: 'convenience',  label: 'Convenience — best route',  icon: '⚡' },
  { value: 'family',       label: 'Family-friendly',           icon: '👨‍👩‍👧' },
];

export default function TripsScreen() {
  const [origin, setOrigin]           = useState('');
  const [destination, setDest]        = useState('');
  const [departDate, setDepart]       = useState('');
  const [returnDate, setReturn]       = useState('');
  const [flexibility, setFlex]        = useState('exact');
  const [passengers, setPassengers]   = useState('1');
  const [cabin, setCabin]             = useState('business');
  const [points, setPoints]           = useState<string[]>([]);
  const [pointsBalance, setPtsBal]    = useState('');
  const [priority, setPriority]       = useState('');
  const [name, setName]               = useState('');
  const [email, setEmail]             = useState('');
  const [notes, setNotes]             = useState('');
  const [loading, setLoading]         = useState(false);
  const [error, setError]             = useState('');
  const [submitted, setSubmitted]     = useState(false);
  const [requestId, setRequestId]     = useState('');

  const prices: Record<string,number> = { economy: 150, premium_economy: 200, business: 350, first: 500 };
  const price = (prices[cabin] || 350) + (Math.max(parseInt(passengers)||1, 1) - 1) * 50;

  function togglePoint(v: string) {
    setPoints(p => p.includes(v) ? p.filter(x => x !== v) : [...p, v]);
  }

  const canSubmit = origin && destination && departDate && name && email.includes('@') && points.length > 0 && priority;

  async function submit() {
    setLoading(true); setError('');
    try {
      const data = await api.tripRequest({
        name, email, origin, destination,
        departDate, returnDate, flexibility,
        passengers: parseInt(passengers) || 1,
        cabin, pointsAvailable: points,
        pointsBalance, priority, notes,
        clientPrice: price,
        contractorPay: Math.round(price * 0.6),
      });
      setRequestId(data.requestId);
      setSubmitted(true);
    } catch(e: any) {
      setError(e.message || 'Submission failed');
    } finally {
      setLoading(false);
    }
  }

  if (submitted) {
    return (
      <View style={styles.successWrap}>
        <Text style={styles.successIcon}>✈️</Text>
        <Text style={styles.successTitle}>Request received</Text>
        <Text style={styles.successSub}>
          We'll research your award options and email you within 24–48 hours with exactly what to book.{'\n\n'}
          Reference: <Text style={{ fontWeight: '600' }}>{requestId}</Text>
        </Text>
        <Button label="Submit another request" onPress={() => setSubmitted(false)} style={{ marginTop: 24 }} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.eyebrow}>Award travel research</Text>
        <Text style={styles.title}>Put your points to <Text style={{ color: C.teal, fontStyle: 'italic' }}>work</Text></Text>
        <Text style={styles.sub}>Submit your trip and we'll find the best award redemption across your programs.</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>

        <Card>
          <SectionTitle>Trip details</SectionTitle>
          <Input label="Flying from" placeholder="New York (JFK)" value={origin} onChangeText={setOrigin} autoCapitalize="words" />
          <Input label="Flying to" placeholder="Tokyo (NRT)" value={destination} onChangeText={setDest} autoCapitalize="words" />
          <Input label="Departure date" placeholder="Aug 15, 2026" value={departDate} onChangeText={setDepart} />
          <Input label="Return date (optional)" placeholder="Aug 25, 2026" value={returnDate} onChangeText={setReturn} />
          <Input label="Number of passengers" placeholder="1" value={passengers} onChangeText={setPassengers} keyboardType="number-pad" />
        </Card>

        <Card>
          <SectionTitle>Cabin class</SectionTitle>
          <View style={styles.cabinGrid}>
            {CABIN_OPTIONS.map(o => (
              <TouchableOpacity key={o.value} style={[styles.cabinBtn, cabin === o.value && styles.cabinBtnSelected]} onPress={() => setCabin(o.value)} activeOpacity={0.7}>
                <Text style={styles.cabinIcon}>{o.icon}</Text>
                <Text style={[styles.cabinLabel, cabin === o.value && styles.cabinLabelSelected]}>{o.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </Card>

        <Card>
          <SectionTitle>Points you can use</SectionTitle>
          <View style={styles.pointsGrid}>
            {POINTS_OPTIONS.map(o => (
              <TouchableOpacity key={o.value} style={[styles.pointsBtn, points.includes(o.value) && styles.pointsBtnSelected]} onPress={() => togglePoint(o.value)} activeOpacity={0.7}>
                <Text style={styles.pointsIcon}>{o.icon}</Text>
                <Text style={[styles.pointsLabel, points.includes(o.value) && styles.pointsLabelSelected]}>{o.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <Input label="Approximate balances" placeholder="e.g. 250k Chase UR + 180k Amex MR" value={pointsBalance} onChangeText={setPtsBal} style={{ marginTop: 12 }} />
        </Card>

        <Card>
          <SectionTitle>What matters most?</SectionTitle>
          <View style={styles.priorityGrid}>
            {PRIORITY_OPTIONS.map(o => (
              <TouchableOpacity key={o.value} style={[styles.priorityBtn, priority === o.value && styles.priorityBtnSelected]} onPress={() => setPriority(o.value)} activeOpacity={0.7}>
                <Text style={styles.priorityIcon}>{o.icon}</Text>
                <Text style={[styles.priorityLabel, priority === o.value && styles.priorityLabelSelected]}>{o.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </Card>

        <Card>
          <SectionTitle>Your details</SectionTitle>
          <Input label="Full name" placeholder="Gerald Noria" value={name} onChangeText={setName} autoCapitalize="words" />
          <Input label="Email address" placeholder="you@company.com" value={email} onChangeText={setEmail} keyboardType="email-address" />
          <Input label="Anything else?" placeholder="Preferences, past denials, upcoming trips..." value={notes} onChangeText={setNotes} multiline />
        </Card>

        <View style={styles.pricingBanner}>
          <Text style={styles.pricingLabel}>Research fee</Text>
          <View style={styles.pricingRow}>
            <Text style={styles.pricingRowLabel}>Award research + availability</Text>
            <Text style={styles.pricingRowVal}>${price}</Text>
          </View>
          <View style={styles.pricingRow}>
            <Text style={styles.pricingRowLabel}>Turnaround</Text>
            <Text style={styles.pricingRowVal}>24–48 hours</Text>
          </View>
        </View>

        <ErrorBanner message={error} />
        <Button label={loading ? 'Submitting...' : 'Submit trip request'} onPress={submit} disabled={!canSubmit} loading={loading} style={{ marginBottom: 32 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  header: { backgroundColor: C.bgCard, paddingTop: 56, paddingHorizontal: 20, paddingBottom: 20, borderBottomWidth: 0.5, borderBottomColor: C.border },
  eyebrow: { fontSize: 11, letterSpacing: 1, textTransform: 'uppercase', color: C.tealDark, fontWeight: '500', marginBottom: 4 },
  title: { fontSize: 26, fontWeight: '400', color: C.text, letterSpacing: -0.5, marginBottom: 6 },
  sub: { fontSize: 13, color: C.textMuted, lineHeight: 19 },
  scroll: { padding: 16, paddingBottom: 40 },
  cabinGrid: { flexDirection: 'row', gap: 8 },
  cabinBtn: { flex: 1, alignItems: 'center', padding: 12, borderRadius: 8, borderWidth: 0.5, borderColor: C.borderStrong, backgroundColor: C.bg },
  cabinBtnSelected: { borderColor: C.teal, backgroundColor: C.tealLight },
  cabinIcon: { fontSize: 20, marginBottom: 4 },
  cabinLabel: { fontSize: 11, color: C.textMuted, textAlign: 'center' },
  cabinLabelSelected: { color: C.tealDark, fontWeight: '500' },
  pointsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  pointsBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, padding: 8, borderRadius: 8, borderWidth: 0.5, borderColor: C.borderStrong, backgroundColor: C.bg },
  pointsBtnSelected: { borderColor: C.teal, backgroundColor: C.tealLight },
  pointsIcon: { fontSize: 14 },
  pointsLabel: { fontSize: 12, color: C.text },
  pointsLabelSelected: { color: C.tealDark, fontWeight: '500' },
  priorityGrid: { gap: 8 },
  priorityBtn: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 12, borderRadius: 8, borderWidth: 0.5, borderColor: C.borderStrong, backgroundColor: C.bg },
  priorityBtnSelected: { borderColor: C.teal, backgroundColor: C.tealLight },
  priorityIcon: { fontSize: 18 },
  priorityLabel: { fontSize: 13, color: C.text },
  priorityLabelSelected: { color: C.tealDark, fontWeight: '500' },
  pricingBanner: { backgroundColor: '#FAEEDA', borderRadius: 12, padding: 16, marginBottom: 12, borderWidth: 0.5, borderColor: '#FAC775' },
  pricingLabel: { fontSize: 11, letterSpacing: 1, textTransform: 'uppercase', color: '#854F0B', marginBottom: 8, fontWeight: '500' },
  pricingRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6, borderBottomWidth: 0.5, borderBottomColor: '#FAC775' },
  pricingRowLabel: { fontSize: 13, color: '#854F0B' },
  pricingRowVal: { fontSize: 13, fontWeight: '600', color: '#633806' },
  successWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32, backgroundColor: C.bg },
  successIcon: { fontSize: 48, marginBottom: 16 },
  successTitle: { fontSize: 24, fontWeight: '400', color: C.text, marginBottom: 10 },
  successSub: { fontSize: 14, color: C.textMuted, textAlign: 'center', lineHeight: 20 },
});
