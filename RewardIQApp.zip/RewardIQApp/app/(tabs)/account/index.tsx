import { useEffect, useState } from 'react';
import { View, Text, ScrollView, StyleSheet, Alert, Linking, Switch } from 'react-native';
import { router } from 'expo-router';
import { supabase } from '@/lib/supabase';
import { C, Card, Button, SectionTitle } from '@/components/ui';
import { BOOKING_URL, ADMIN_EMAIL } from '@/lib/constants';

export default function AccountScreen() {
  const [user, setUser]   = useState<any>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) { router.replace('/(auth)/login'); return; }
      setUser(session.user);
    });
  }, []);

  async function signOut() {
    Alert.alert('Sign out', 'Are you sure you want to sign out?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign out', style: 'destructive', onPress: async () => {
        await supabase.auth.signOut();
        router.replace('/(auth)/login');
      }},
    ]);
  }

  if (!user) return null;

  const firstName  = (user.user_metadata?.name || user.email || '').split(/[\s@]/)[0];
  const isAdmin    = user.email === ADMIN_EMAIL;

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.scroll}>
      <Text style={styles.pageTitle}>Account</Text>

      {/* Profile */}
      <Card>
        <View style={styles.profileRow}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>{firstName[0]?.toUpperCase()}</Text>
          </View>
          <View>
            <Text style={styles.name}>{user.user_metadata?.name || firstName}</Text>
            <Text style={styles.email}>{user.email}</Text>
            <Text style={styles.joined}>Member since {new Date(user.created_at).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</Text>
          </View>
        </View>
      </Card>

      {/* Quick actions */}
      <SectionTitle>Quick actions</SectionTitle>
      <Card>
        <Button label="✨ Run new analysis" onPress={() => router.push('/(tabs)/analysis')} style={{ marginBottom: 8 }} />
        <Button label="✈️ Request trip research" onPress={() => router.push('/(tabs)/trips')} variant="outline" style={{ marginBottom: 8 }} />
        <Button label="📅 Book a strategy session" onPress={() => Linking.openURL(BOOKING_URL)} variant="outline" />
      </Card>

      {/* Links */}
      <SectionTitle>Resources</SectionTitle>
      <Card>
        {[
          { label: '📋 Pre-call intake form', url: 'https://rewardiq.denorgerald.workers.dev/intake' },
          { label: '🏗️ Contractor portal',     url: 'https://rewardiq.denorgerald.workers.dev/contractor' },
          { label: '📧 Contact us',             url: 'https://rewardiq.denorgerald.workers.dev/contact' },
        ].map((item, i) => (
          <Button key={i} label={item.label} onPress={() => Linking.openURL(item.url)} variant="ghost" style={{ justifyContent: 'flex-start', paddingVertical: 12, borderBottomWidth: i < 2 ? 0.5 : 0, borderBottomColor: C.border, borderRadius: 0 }} />
        ))}
      </Card>

      {/* Admin link */}
      {isAdmin && (
        <>
          <SectionTitle>Admin</SectionTitle>
          <Card>
            <Button label="🔧 Open admin dashboard" onPress={() => router.push('/admin')} variant="outline" />
          </Card>
        </>
      )}

      {/* Sign out */}
      <Button label="Sign out" onPress={signOut} variant="outline" style={{ marginTop: 8, borderColor: C.redBorder }} />

      <Text style={styles.disclaimer}>
        RewardIQ v1.0 · Not financial advice · Your data is private and secure
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  scroll: { padding: 16, paddingTop: 56, paddingBottom: 40 },
  pageTitle: { fontSize: 28, fontWeight: '400', color: C.text, letterSpacing: -0.5, marginBottom: 20 },
  profileRow: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  avatar: { width: 52, height: 52, borderRadius: 26, backgroundColor: C.tealLight, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 20, fontWeight: '700', color: C.tealDark },
  name: { fontSize: 17, fontWeight: '500', color: C.text },
  email: { fontSize: 12, color: C.textMuted, marginTop: 2 },
  joined: { fontSize: 11, color: C.textHint, marginTop: 2 },
  disclaimer: { fontSize: 11, color: C.textHint, textAlign: 'center', marginTop: 24 },
});
