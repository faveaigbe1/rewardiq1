import { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity,
  TextInput, StyleSheet, Alert
} from 'react-native';
import { router } from 'expo-router';
import { useAnalysisStore } from '@/lib/store';
import { api } from '@/lib/api';
import { C, Card, Button, Chip, SectionTitle, ErrorBanner } from '@/components/ui';
import { SPEND_OPTIONS, CATEGORIES, GOALS } from '@/lib/constants';

export default function AnalysisScreen() {
  const store   = useAnalysisStore();
  const [error, setError]     = useState('');
  const [loading, setLoading] = useState(false);

  const canSubmit = store.spendAmount && store.categories.length > 0 && store.goal && store.email.includes('@');

  async function runAnalysis() {
    if (!canSubmit) return;
    setLoading(true);
    setError('');
    try {
      const data = await api.analyze({
        spendAmount: store.spendAmount,
        categories:  store.categories,
        currentCard: store.currentCard,
        goal:        store.goal,
        email:       store.email,
      });
      store.setAnalysis(data.analysis);
      router.push('/(tabs)/analysis/teaser');
    } catch (e: any) {
      setError(e.message || 'Analysis failed. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.logo}>Reward<Text style={{ color: C.teal }}>IQ</Text></Text>
        <Text style={styles.eyebrow}>US Business Card Optimizer</Text>
        <Text style={styles.title}>Find the money you're{'\n'}<Text style={{ color: C.teal, fontStyle: 'italic' }}>leaving behind</Text></Text>
        <Text style={styles.subtitle}>Enter your spend profile and discover your optimal card stack in 30 seconds.</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>

        {/* Spend */}
        <Card>
          <SectionTitle>Your spend profile</SectionTitle>
          <Text style={styles.label}>Monthly business spend</Text>
          <View style={styles.optionGrid}>
            {SPEND_OPTIONS.map(o => (
              <TouchableOpacity
                key={o.value}
                style={[styles.optBtn, store.spendAmount === o.value && styles.optBtnSelected]}
                onPress={() => store.setSpend(o.value)}
                activeOpacity={0.7}
              >
                <Text style={[styles.optText, store.spendAmount === o.value && styles.optTextSelected]}>
                  {o.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </Card>

        {/* Categories */}
        <Card>
          <SectionTitle>Top spending categories</SectionTitle>
          <Text style={styles.hint}>Select all that apply</Text>
          <View style={styles.chipGrid}>
            {CATEGORIES.map(c => (
              <Chip
                key={c.value}
                icon={c.icon}
                label={c.label}
                selected={store.categories.includes(c.value)}
                onPress={() => store.toggleCat(c.value)}
              />
            ))}
          </View>
        </Card>

        {/* Current card */}
        <Card>
          <Text style={styles.label}>Current primary card</Text>
          <TextInput
            style={styles.input}
            placeholder="e.g. Chase Sapphire, local bank card..."
            placeholderTextColor={C.textHint}
            value={store.currentCard}
            onChangeText={store.setCard}
            autoCapitalize="words"
          />
        </Card>

        {/* Goals */}
        <Card>
          <SectionTitle>What matters most to you?</SectionTitle>
          <View style={styles.goalGrid}>
            {GOALS.map(g => (
              <TouchableOpacity
                key={g.value}
                style={[styles.goalBtn, store.goal === g.value && styles.goalBtnSelected]}
                onPress={() => store.setGoal(g.value)}
                activeOpacity={0.7}
              >
                <Text style={styles.goalIcon}>{g.icon}</Text>
                <Text style={[styles.goalLabel, store.goal === g.value && styles.goalLabelSelected]}>
                  {g.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </Card>

        {/* Email */}
        <Card>
          <SectionTitle>Where to send your report</SectionTitle>
          <Text style={styles.label}>Email address</Text>
          <TextInput
            style={styles.input}
            placeholder="you@company.com"
            placeholderTextColor={C.textHint}
            value={store.email}
            onChangeText={store.setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
          />
        </Card>

        <ErrorBanner message={error} />

        <Button
          label={loading ? 'Analyzing...' : '✨ Analyze my rewards potential'}
          onPress={runAnalysis}
          disabled={!canSubmit}
          loading={loading}
          style={{ marginBottom: 32 }}
        />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  header: { backgroundColor: C.bgCard, paddingTop: 56, paddingHorizontal: 20, paddingBottom: 20, borderBottomWidth: 0.5, borderBottomColor: C.border },
  logo: { fontSize: 22, fontWeight: '700', color: C.text, letterSpacing: -0.5, marginBottom: 4 },
  eyebrow: { fontSize: 11, letterSpacing: 1, textTransform: 'uppercase', color: C.tealDark, fontWeight: '500', marginBottom: 6 },
  title: { fontSize: 26, fontWeight: '400', color: C.text, lineHeight: 32, letterSpacing: -0.5, marginBottom: 8 },
  subtitle: { fontSize: 13, color: C.textMuted, lineHeight: 19 },
  scroll: { padding: 16, paddingBottom: 40 },
  label: { fontSize: 13, fontWeight: '500', color: C.text, marginBottom: 8 },
  hint: { fontSize: 12, color: C.textHint, marginBottom: 10 },
  optionGrid: { gap: 8 },
  optBtn: { padding: 12, borderRadius: 8, borderWidth: 0.5, borderColor: C.borderStrong, backgroundColor: C.bg },
  optBtnSelected: { borderColor: C.teal, backgroundColor: C.tealLight },
  optText: { fontSize: 14, color: C.text },
  optTextSelected: { color: C.tealDark, fontWeight: '500' },
  chipGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  goalGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  goalBtn: { width: '30%', padding: 12, borderRadius: 8, borderWidth: 0.5, borderColor: C.borderStrong, backgroundColor: C.bg, alignItems: 'center' },
  goalBtnSelected: { borderColor: C.teal, backgroundColor: C.tealLight },
  goalIcon: { fontSize: 22, marginBottom: 4 },
  goalLabel: { fontSize: 11, color: C.textMuted, textAlign: 'center', lineHeight: 14 },
  goalLabelSelected: { color: C.tealDark, fontWeight: '500' },
  input: { backgroundColor: C.bg, borderWidth: 0.5, borderColor: C.borderStrong, borderRadius: 8, paddingHorizontal: 14, paddingVertical: 11, fontSize: 14, color: C.text },
});
