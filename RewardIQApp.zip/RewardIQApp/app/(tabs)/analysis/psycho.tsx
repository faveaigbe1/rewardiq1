import { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { router } from 'expo-router';
import { useAnalysisStore } from '@/lib/store';
import { api } from '@/lib/api';
import { C, Card, Button, SectionTitle, ErrorBanner } from '@/components/ui';
import { Linking } from 'react-native';
import { STRIPE_REPORT_LINK } from '@/lib/constants';

const EMPLOYEES = [
  { value: 'solo',  label: 'Just me',      icon: '🧑‍💻' },
  { value: '2-10',  label: '2–10 people',  icon: '👥' },
  { value: '11-50', label: '11–50 people', icon: '🏢' },
  { value: '50+',   label: '50+ people',   icon: '🏗️' },
];
const STYLES = [
  { value: 'diy',          label: 'DIY — I\'ll implement myself',  icon: '🛠️' },
  { value: 'collaborative', label: 'Collaborative — guide me',      icon: '🤝' },
  { value: 'done_for_you', label: 'Done-for-you — just handle it', icon: '✨' },
];
const URGENCY = [
  { value: 'now',        label: 'Right now',    icon: '🔥' },
  { value: 'next_month', label: 'Next month',   icon: '📅' },
  { value: '3-6_months', label: '3–6 months',  icon: '🗓️' },
  { value: 'exploring',  label: 'Exploring',    icon: '🔍' },
];
const PAID = [
  { value: 'yes_regularly', label: 'Yes, regularly',    icon: '💳' },
  { value: 'yes_once',      label: 'Yes, once/twice',   icon: '✅' },
  { value: 'no_would',      label: 'No, but I would',   icon: '🤔' },
  { value: 'no_diy',        label: 'No — prefer DIY',   icon: '🙅' },
];
const TRAVEL = [
  { value: '0-2',  label: '0–2 trips',  icon: '🏠' },
  { value: '3-5',  label: '3–5 trips',  icon: '🧳' },
  { value: '6-12', label: '6–12 trips', icon: '✈️' },
  { value: '12+',  label: '12+ trips',  icon: '🌍' },
];

function OptionGrid({ options, value, onSelect }: {
  options: { value: string; label: string; icon: string }[];
  value: string;
  onSelect: (v: string) => void;
}) {
  return (
    <View style={styles.optGrid}>
      {options.map(o => (
        <TouchableOpacity
          key={o.value}
          style={[styles.optBtn, value === o.value && styles.optBtnSelected]}
          onPress={() => onSelect(o.value)}
          activeOpacity={0.7}
        >
          <Text style={styles.optIcon}>{o.icon}</Text>
          <Text style={[styles.optLabel, value === o.value && styles.optLabelSelected]}>{o.label}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

export default function PsychoScreen() {
  const store   = useAnalysisStore();
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState('');

  const allFilled = store.psycho.employees && store.psycho.style &&
    store.psycho.urgency && store.psycho.paidBefore && store.psycho.travel;

  async function submit() {
    if (!allFilled) return;
    setLoading(true);
    setError('');
    try {
      // Fire segment call — await so it completes before Stripe
      await api.segment({
        email:       store.email,
        spendAmount: store.spendAmount,
        employees:   store.psycho.employees,
        style:       store.psycho.style,
        urgency:     store.psycho.urgency,
        paidBefore:  store.psycho.paidBefore,
        travel:      store.psycho.travel,
      });
      // Open Stripe payment link
      const url = `${STRIPE_REPORT_LINK}?prefilled_email=${encodeURIComponent(store.email)}`;
      await Linking.openURL(url);
      // Navigate to results (will show after they pay and return)
      router.push('/(tabs)/analysis/results');
    } catch(e: any) {
      setError(e.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.scroll}>
      <View style={styles.headerWrap}>
        <Text style={styles.eyebrow}>2 minutes · personalizes your report</Text>
        <Text style={styles.title}>Tell us a bit more</Text>
        <Text style={styles.sub}>5 quick questions so your report is actually useful to you.</Text>
      </View>

      <Card>
        <SectionTitle>Team size</SectionTitle>
        <OptionGrid options={EMPLOYEES} value={store.psycho.employees} onSelect={v => store.setPsycho('employees', v)} />
      </Card>

      <Card>
        <SectionTitle>How do you prefer to work?</SectionTitle>
        <OptionGrid options={STYLES} value={store.psycho.style} onSelect={v => store.setPsycho('style', v)} />
      </Card>

      <Card>
        <SectionTitle>When do you want to optimize?</SectionTitle>
        <OptionGrid options={URGENCY} value={store.psycho.urgency} onSelect={v => store.setPsycho('urgency', v)} />
      </Card>

      <Card>
        <SectionTitle>Paid for consulting before?</SectionTitle>
        <OptionGrid options={PAID} value={store.psycho.paidBefore} onSelect={v => store.setPsycho('paidBefore', v)} />
      </Card>

      <Card>
        <SectionTitle>Business trips per year</SectionTitle>
        <OptionGrid options={TRAVEL} value={store.psycho.travel} onSelect={v => store.setPsycho('travel', v)} />
      </Card>

      <ErrorBanner message={error} />

      <Button label={loading ? 'Saving profile...' : 'Continue to checkout →'} onPress={submit} disabled={!allFilled} loading={loading} />
      <Button label="← Back" onPress={() => router.back()} variant="outline" style={{ marginTop: 8, marginBottom: 32 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  scroll: { padding: 16, paddingTop: 56, paddingBottom: 40 },
  headerWrap: { marginBottom: 20 },
  eyebrow: { fontSize: 11, letterSpacing: 1, textTransform: 'uppercase', color: C.tealDark, fontWeight: '500', marginBottom: 6 },
  title: { fontSize: 26, fontWeight: '400', color: C.text, letterSpacing: -0.5, marginBottom: 6 },
  sub: { fontSize: 13, color: C.textMuted, lineHeight: 19 },
  optGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  optBtn: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 10, borderRadius: 8, borderWidth: 0.5, borderColor: C.borderStrong, backgroundColor: C.bg, minWidth: '47%', flex: 1 },
  optBtnSelected: { borderColor: C.teal, backgroundColor: C.tealLight },
  optIcon: { fontSize: 16 },
  optLabel: { fontSize: 12, color: C.text, flex: 1 },
  optLabelSelected: { color: C.tealDark, fontWeight: '500' },
});
