import { useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { router } from 'expo-router';
import { api } from '@/lib/api';
import { useAnalysisStore } from '@/lib/store';
import { C, Button } from '@/components/ui';

export default function PendingScreen() {
  const { email } = useAnalysisStore();

  return (
    <View style={styles.container}>
      <Text style={styles.icon}>📬</Text>
      <Text style={styles.title}>Complete payment to unlock</Text>
      <Text style={styles.sub}>
        After completing payment in your browser, your full report and PDF will be emailed to{'\n'}
        <Text style={{ fontWeight: '600', color: C.text }}>{email}</Text>
        {'\n\n'}Check your inbox — it arrives within 60 seconds of payment.
      </Text>
      <Button
        label="View my dashboard"
        onPress={() => router.replace('/(tabs)/dashboard')}
        style={{ marginTop: 24 }}
      />
      <Button
        label="Run another analysis"
        onPress={() => { useAnalysisStore.getState().reset(); router.replace('/(tabs)/analysis'); }}
        variant="outline"
        style={{ marginTop: 10 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center', padding: 32 },
  icon: { fontSize: 56, marginBottom: 16 },
  title: { fontSize: 22, fontWeight: '600', color: C.text, marginBottom: 12, textAlign: 'center' },
  sub: { fontSize: 14, color: C.textMuted, textAlign: 'center', lineHeight: 22 },
});
