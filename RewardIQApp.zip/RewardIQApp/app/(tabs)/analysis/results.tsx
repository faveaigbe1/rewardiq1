import { useEffect, useState } from 'react';
import { View, Text, ScrollView, StyleSheet, ActivityIndicator } from 'react-native';
import { router } from 'expo-router';
import { useAnalysisStore } from '@/lib/store';
import { api } from '@/lib/api';
import { C, Card, Button, SectionTitle } from '@/components/ui';

export default function ResultsScreen() {
  const { analysis, email } = useAnalysisStore();
  const r = analysis;
  const [sending, setSending] = useState(true);

  useEffect(() => {
    // Trigger PDF send
    api.sendReport(email).catch(() => {}).finally(() => setSending(false));
  }, []);

  if (!r) { router.replace('/(tabs)/analysis'); return null; }

  const today = new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.scroll}>

      {/* Unlocked badge */}
      <View style={styles.unlockedBadge}>
        <Text style={styles.unlockedText}>✅ Full report unlocked</Text>
      </View>

      {/* Mailbox notice */}
      <View style={styles.mailboxBanner}>
        <Text style={styles.mailboxIcon}>📬</Text>
        <Text style={styles.mailboxText}>
          Your PDF report has been sent to <Text style={{ fontWeight: '600' }}>{email}</Text> — check your inbox.
        </Text>
      </View>

      <Text style={styles.sectionHeading}>Your complete strategy</Text>
      <Text style={styles.summaryLine}>{r.summary_line}</Text>

      {/* Gap banner */}
      <View style={styles.gapBanner}>
        <View>
          <Text style={styles.gapLabel}>Annual rewards gap</Text>
          <Text style={styles.gapAmount}>${(r.gap || 0).toLocaleString()}</Text>
          <Text style={styles.gapSub}>same spend · no behavior change needed</Text>
        </View>
        <View style={{ alignItems: 'flex-end' }}>
          <Text style={styles.gapFlow}>
            <Text style={{ fontWeight: '700' }}>${(r.current_annual_value || 0).toLocaleString()}</Text>
            {' → '}
            <Text style={{ fontWeight: '700' }}>${(r.optimized_annual_value || 0).toLocaleString()}</Text>
          </Text>
          <Text style={styles.gapFlowSub}>current → optimized/yr</Text>
        </View>
      </View>

      {/* Metrics */}
      <View style={styles.metricsRow}>
        <View style={styles.metricCard}>
          <Text style={styles.metricLabel}>Currently earning</Text>
          <Text style={styles.metricVal}>${(r.current_annual_value || 0).toLocaleString()}</Text>
        </View>
        <View style={styles.metricCard}>
          <Text style={styles.metricLabel}>Optimized value</Text>
          <Text style={[styles.metricVal, { color: C.tealDark }]}>${(r.optimized_annual_value || 0).toLocaleString()}</Text>
        </View>
      </View>

      {/* Warning */}
      {r.pricing_warning ? (
        <View style={styles.warningBanner}>
          <Text style={styles.warningText}>⚠️ {r.pricing_warning}</Text>
        </View>
      ) : null}

      {/* Card recommendations */}
      <SectionTitle>Your optimal card stack</SectionTitle>
      {(r.cards || []).map((c: any, i: number) => (
        <Card key={i} style={c.is_primary && styles.primaryCard}>
          {c.is_primary && (
            <View style={styles.bestFitBadge}>
              <Text style={styles.bestFitText}>Best fit</Text>
            </View>
          )}
          <View style={styles.cardHeader}>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardName}>{c.name}</Text>
              <Text style={styles.cardIssuer}>{c.issuer} · ${c.annual_fee}/yr</Text>
            </View>
            <View style={{ alignItems: 'flex-end' }}>
              <Text style={styles.cardRate}>{c.earn_rate}</Text>
              <Text style={styles.cardRateSub}>{c.earn_description}</Text>
            </View>
          </View>
          <Text style={styles.cardReason}>{c.reason}</Text>
          <View style={styles.tags}>
            {(c.tags || []).map((t: string) => (
              <View key={t} style={[styles.tag, c.is_primary && styles.tagPrimary]}>
                <Text style={[styles.tagText, c.is_primary && styles.tagTextPrimary]}>{t}</Text>
              </View>
            ))}
          </View>
        </Card>
      ))}

      {/* Sweet spot */}
      {r.sweet_spot?.applies && (
        <>
          <SectionTitle>Sweet spot for your goal</SectionTitle>
          <View style={styles.sweetSpot}>
            <Text style={styles.sweetLabel}>🔥 HIGH-VALUE REDEMPTION</Text>
            <Text style={styles.sweetTitle}>{r.sweet_spot.title}</Text>
            <Text style={styles.sweetDetail}>{r.sweet_spot.detail}</Text>
          </View>
        </>
      )}

      {/* Implementation steps */}
      <SectionTitle>Implementation checklist</SectionTitle>
      <Card>
        {(r.implementation_steps || []).map((s: string, i: number) => (
          <View key={i} style={[styles.checkItem, i > 0 && styles.checkItemBorder]}>
            <View style={styles.checkNum}>
              <Text style={styles.checkNumText}>{i + 1}</Text>
            </View>
            <Text style={styles.checkText}>{s}</Text>
          </View>
        ))}
      </Card>

      <Text style={styles.verified}>✦ Data verified {today} · PDF sent to {email}</Text>

      <Button label="← Analyze a different profile" onPress={() => { useAnalysisStore.getState().reset(); router.replace('/(tabs)/analysis'); }} variant="outline" style={{ marginBottom: 32 }} />

      <Text style={styles.disclaimer}>
        Disclaimer: RewardIQ provides general rewards optimization information for educational purposes only.
        Card terms, earn rates, and award charts change frequently — always verify directly with the card issuer.
        This is not financial advice.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  scroll: { padding: 16, paddingTop: 56, paddingBottom: 40 },
  unlockedBadge: { backgroundColor: C.tealLight, borderRadius: 100, paddingHorizontal: 14, paddingVertical: 5, alignSelf: 'center', marginBottom: 12 },
  unlockedText: { fontSize: 12, color: C.tealDark, fontWeight: '500' },
  mailboxBanner: { flexDirection: 'row', gap: 10, backgroundColor: C.tealLight, borderRadius: 10, padding: 12, marginBottom: 16, alignItems: 'flex-start' },
  mailboxIcon: { fontSize: 18 },
  mailboxText: { fontSize: 13, color: C.tealDark, flex: 1, lineHeight: 18 },
  sectionHeading: { fontSize: 22, fontWeight: '400', color: C.text, letterSpacing: -0.5, marginBottom: 4, textAlign: 'center' },
  summaryLine: { fontSize: 13, color: C.textMuted, textAlign: 'center', marginBottom: 16 },
  gapBanner: { backgroundColor: C.tealLight, borderRadius: 12, padding: 16, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10, borderWidth: 0.5, borderColor: C.tealMid },
  gapLabel: { fontSize: 12, color: C.tealDark, marginBottom: 2 },
  gapAmount: { fontSize: 32, fontWeight: '700', color: C.tealDarker, letterSpacing: -1 },
  gapSub: { fontSize: 11, color: C.teal },
  gapFlow: { fontSize: 13, color: C.tealDark },
  gapFlowSub: { fontSize: 11, color: C.teal, marginTop: 2 },
  metricsRow: { flexDirection: 'row', gap: 10, marginBottom: 12 },
  metricCard: { flex: 1, backgroundColor: C.bgSurface, borderRadius: 8, padding: 12 },
  metricLabel: { fontSize: 12, color: C.textMuted, marginBottom: 4 },
  metricVal: { fontSize: 20, fontWeight: '600', color: C.text },
  warningBanner: { backgroundColor: C.redLight, borderRadius: 8, padding: 12, marginBottom: 12, borderWidth: 0.5, borderColor: C.redBorder },
  warningText: { fontSize: 13, color: C.redText },
  primaryCard: { borderWidth: 1.5, borderColor: C.teal },
  bestFitBadge: { position: 'absolute', top: 0, right: 12, backgroundColor: C.teal, borderBottomLeftRadius: 6, borderBottomRightRadius: 6, paddingHorizontal: 10, paddingVertical: 3 },
  bestFitText: { fontSize: 10, color: '#fff', fontWeight: '500' },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  cardName: { fontSize: 15, fontWeight: '500', color: C.text },
  cardIssuer: { fontSize: 12, color: C.textMuted, marginTop: 2 },
  cardRate: { fontSize: 22, fontWeight: '700', color: C.teal },
  cardRateSub: { fontSize: 11, color: C.textMuted, textAlign: 'right' },
  cardReason: { fontSize: 13, color: C.textMuted, lineHeight: 19, paddingTop: 10, borderTopWidth: 0.5, borderTopColor: C.border, marginBottom: 10 },
  tags: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  tag: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 100, borderWidth: 0.5, borderColor: C.borderStrong, backgroundColor: C.bg },
  tagPrimary: { backgroundColor: C.tealLight, borderColor: C.tealMid },
  tagText: { fontSize: 11, color: C.textMuted },
  tagTextPrimary: { color: C.tealDark },
  sweetSpot: { backgroundColor: '#FAEEDA', borderRadius: 12, padding: 16, marginBottom: 16, borderWidth: 0.5, borderColor: '#FAC775' },
  sweetLabel: { fontSize: 10, letterSpacing: 1, color: '#854F0B', marginBottom: 6 },
  sweetTitle: { fontSize: 15, fontWeight: '600', color: '#633806', marginBottom: 6 },
  sweetDetail: { fontSize: 13, color: '#854F0B', lineHeight: 19 },
  checkItem: { flexDirection: 'row', gap: 10, paddingVertical: 8, alignItems: 'flex-start' },
  checkItemBorder: { borderTopWidth: 0.5, borderTopColor: C.border },
  checkNum: { width: 22, height: 22, borderRadius: 11, backgroundColor: C.tealLight, alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 1 },
  checkNumText: { fontSize: 11, color: C.tealDark, fontWeight: '600' },
  checkText: { fontSize: 13, color: C.text, flex: 1, lineHeight: 19 },
  verified: { fontSize: 11, color: C.textHint, textAlign: 'center', marginVertical: 12 },
  disclaimer: { fontSize: 11, color: C.textHint, lineHeight: 16, textAlign: 'center', marginBottom: 16, padding: 12, backgroundColor: C.bgSurface, borderRadius: 8 },
});
