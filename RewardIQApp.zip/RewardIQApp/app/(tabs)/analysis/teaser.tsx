import { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Linking } from 'react-native';
import { router } from 'expo-router';
import { useAnalysisStore } from '@/lib/store';
import { C, Card, Button, SectionTitle } from '@/components/ui';
import { REPORT_PRICE, STRIPE_REPORT_LINK } from '@/lib/constants';

export default function TeaserScreen() {
  const { analysis, email } = useAnalysisStore();
  const r = analysis;
  if (!r) { router.replace('/(tabs)/analysis'); return null; }

  const today = new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });

  function unlockReport() {
    router.push('/(tabs)/analysis/psycho');
  }

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.scroll}>

      {/* Gap banner */}
      <View style={styles.gapBanner}>
        <Text style={styles.gapEyebrow}>Your annual rewards gap</Text>
        <Text style={styles.gapAmount}>${(r.gap || 0).toLocaleString()}</Text>
        <Text style={styles.gapSub}>left on the table every year · same spend</Text>
        <View style={styles.compareRow}>
          <View style={styles.compareItem}>
            <Text style={styles.compareVal}>${(r.current_annual_value || 0).toLocaleString()}</Text>
            <Text style={styles.compareLabel}>Currently earning</Text>
          </View>
          <Text style={styles.compareArrow}>→</Text>
          <View style={styles.compareItem}>
            <Text style={styles.compareVal}>${(r.optimized_annual_value || 0).toLocaleString()}</Text>
            <Text style={styles.compareLabel}>Optimized value</Text>
          </View>
        </View>
      </View>

      {r.summary_line && (
        <Text style={styles.summaryLine}>{r.summary_line}</Text>
      )}

      {/* Top card */}
      <Card>
        <Text style={styles.topCardLabel}>🏆 Your #1 recommended card</Text>
        <View style={styles.topCardRow}>
          <View>
            <Text style={styles.topCardName}>{r.top_card?.name}</Text>
            <Text style={styles.topCardIssuer}>{r.top_card?.issuer}</Text>
          </View>
          <View style={{ alignItems: 'flex-end' }}>
            <Text style={styles.topCardRate}>{r.top_card?.earn_rate}</Text>
            <Text style={styles.topCardRateSub}>{r.top_card?.earn_description}</Text>
          </View>
        </View>
      </Card>

      {/* Locked section */}
      <Card style={styles.lockedCard}>
        <View style={styles.lockOverlay}>
          <Text style={styles.lockIcon}>🔒</Text>
          <View style={styles.priceBadge}>
            <Text style={styles.priceBadgeText}>Full report — {REPORT_PRICE}</Text>
          </View>
          <Text style={styles.lockTitle}>Unlock your complete card stack</Text>
          <Text style={styles.lockSub}>
            Full 2–3 card strategy · Sweet spot redemption{'\n'}
            Implementation checklist · PDF emailed in 60 seconds
          </Text>
          <Button label={`🔓 Get full report — ${REPORT_PRICE}`} onPress={unlockReport} style={{ marginTop: 12 }} />
        </View>
        {/* Blurred preview */}
        <View style={styles.fakeCards}>
          {(r.cards || []).map((c: any, i: number) => (
            <View key={i} style={[styles.fakeRow, { opacity: 0.15 }]}>
              <Text style={styles.fakeName}>{i === 0 ? c.name : '••••• ••••• Card'}</Text>
              <Text style={styles.fakeRate}>{i === 0 ? c.earn_rate : '██'}</Text>
            </View>
          ))}
        </View>
      </Card>

      <Text style={styles.verified}>✦ Data verified {today} · Program rules checked live</Text>

      <Button
        label="← Start over"
        onPress={() => { useAnalysisStore.getState().reset(); router.replace('/(tabs)/analysis'); }}
        variant="outline"
        style={{ marginBottom: 32 }}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bg },
  scroll: { padding: 16, paddingTop: 56 },
  gapBanner: { backgroundColor: C.tealDark, borderRadius: 16, padding: 24, marginBottom: 12, alignItems: 'center' },
  gapEyebrow: { fontSize: 11, letterSpacing: 1, textTransform: 'uppercase', color: 'rgba(255,255,255,0.7)', marginBottom: 6 },
  gapAmount: { fontSize: 52, fontWeight: '700', color: '#fff', letterSpacing: -1, lineHeight: 56 },
  gapSub: { fontSize: 13, color: 'rgba(255,255,255,0.8)', marginBottom: 16 },
  compareRow: { flexDirection: 'row', alignItems: 'center', gap: 16, borderTopWidth: 0.5, borderTopColor: 'rgba(255,255,255,0.2)', paddingTop: 14, width: '100%', justifyContent: 'center' },
  compareItem: { alignItems: 'center' },
  compareVal: { fontSize: 18, fontWeight: '600', color: '#fff' },
  compareLabel: { fontSize: 11, color: 'rgba(255,255,255,0.65)' },
  compareArrow: { fontSize: 18, color: 'rgba(255,255,255,0.4)' },
  summaryLine: { fontSize: 13, color: C.textMuted, textAlign: 'center', marginBottom: 12, lineHeight: 18 },
  topCardLabel: { fontSize: 11, letterSpacing: 1, textTransform: 'uppercase', color: C.textHint, marginBottom: 10 },
  topCardRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  topCardName: { fontSize: 16, fontWeight: '500', color: C.text },
  topCardIssuer: { fontSize: 12, color: C.textMuted, marginTop: 2 },
  topCardRate: { fontSize: 24, fontWeight: '700', color: C.teal },
  topCardRateSub: { fontSize: 11, color: C.textMuted, textAlign: 'right' },
  lockedCard: { padding: 0, overflow: 'hidden', position: 'relative', minHeight: 200 },
  lockOverlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 10, backgroundColor: 'rgba(250,250,249,0.92)', alignItems: 'center', justifyContent: 'center', padding: 20, borderRadius: 12 },
  lockIcon: { fontSize: 28, marginBottom: 8 },
  priceBadge: { backgroundColor: C.tealLight, borderRadius: 100, paddingHorizontal: 12, paddingVertical: 3, marginBottom: 8 },
  priceBadgeText: { fontSize: 11, color: C.tealDark, fontWeight: '500' },
  lockTitle: { fontSize: 15, fontWeight: '600', color: C.text, marginBottom: 6, textAlign: 'center' },
  lockSub: { fontSize: 13, color: C.textMuted, textAlign: 'center', lineHeight: 19 },
  fakeCards: { padding: 16, gap: 12 },
  fakeRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 8, borderBottomWidth: 0.5, borderBottomColor: C.border },
  fakeName: { fontSize: 14, fontWeight: '500', color: C.text },
  fakeRate: { fontSize: 18, fontWeight: '700', color: C.teal },
  verified: { fontSize: 11, color: C.textHint, textAlign: 'center', marginVertical: 12 },
});
