import { Tabs } from 'expo-router';
import { View, Text, StyleSheet } from 'react-native';
import { C } from '@/components/ui';

function TabIcon({ emoji, label, focused }: { emoji: string; label: string; focused: boolean }) {
  return (
    <View style={styles.tabItem}>
      <Text style={styles.tabEmoji}>{emoji}</Text>
      <Text style={[styles.tabLabel, focused && styles.tabLabelActive]}>{label}</Text>
    </View>
  );
}

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: styles.tabBar,
        tabBarShowLabel: false,
      }}
    >
      <Tabs.Screen
        name="analysis"
        options={{
          tabBarIcon: ({ focused }) => <TabIcon emoji="✨" label="Analyze" focused={focused} />,
        }}
      />
      <Tabs.Screen
        name="trips"
        options={{
          tabBarIcon: ({ focused }) => <TabIcon emoji="✈️" label="Trips" focused={focused} />,
        }}
      />
      <Tabs.Screen
        name="dashboard"
        options={{
          tabBarIcon: ({ focused }) => <TabIcon emoji="📊" label="Dashboard" focused={focused} />,
        }}
      />
      <Tabs.Screen
        name="account"
        options={{
          tabBarIcon: ({ focused }) => <TabIcon emoji="👤" label="Account" focused={focused} />,
        }}
      />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    backgroundColor: C.bgCard,
    borderTopWidth: 0.5,
    borderTopColor: C.border,
    paddingTop: 8,
    height: 72,
  },
  tabItem: { alignItems: 'center', gap: 3 },
  tabEmoji: { fontSize: 20 },
  tabLabel: { fontSize: 10, color: C.textHint, fontWeight: '500' },
  tabLabelActive: { color: C.teal },
});
