import { Stack } from 'expo-router';
export default function ContractorLayout() {
  return <Stack screenOptions={{ headerShown: false }} />;
}
