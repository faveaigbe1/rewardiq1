import { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, TextInput, TouchableOpacity, Alert, RefreshControl } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { api } from '@/lib/api';
import { C, Card, Button, SectionTitle, ErrorBanner, LoadingScreen, EmptyState } from '@/components/ui';

type Job = {
  requestId: string; origin: string; destination: string;
  departDate: string; returnDate: string; cabin: string;
  passengers: number; pointsAvailable: string[]; priority: string;
  notes: string; status: string; claimedBy: string;
  clientPrice: number; contractorPay: number;
};

export default function ContractorScreen() {
  const [screen, setScreen]         = useState<'login'|'sent'|'dashboard'>('login');
  const [email, setEmail]           = useState('');
  const [contractorEmail, setCEmail]= useState('');
  const [contractorName, setCName]  = useState('');
  const [jobs, setJobs]             = useState<Job[]>([]);
  const [tab, setTab]               = useState<'open'|'mine'|'completed'>('open');
  const [loading, setLoading]       = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError]           = useState('');
  const [findingsOpen, setFindingsOpen] = useState<string|null>(null);
  const [findingsText, setFindingsText] = useState('');

  useEffect(() => {
    AsyncStorage.getItem('contractor_session').then(val => {
      if (val) {
        const { email, name } = JSON.parse(val);
        setCEmail(email); setCName(name);
        setScreen('dashboard');
        loadJobs(email);
      }
    });
  }, []);

  async function sendLink() {
    if (!email.includes('@')) { setError('Enter a valid email'); return; }
    setLoading(true); setError('');
    try {
      await api.contractorLogin(email);
      setScreen('sent');
    } catch(e: any) {
      setError(e.message);
    } finally { setLoading(false); }
  }

  async function loadJobs(emailToUse = contractorEmail) {
    setLoading(true);
    try {
      const data = await api.contractorJobs(emailToUse);
      setJobs(data.jobs || []);
    } catch(e: any) {
      setError(e.message);
    } finally { setLoading(false); setRefreshing(false); }
  }

  async function claimJob(requestId: string) {
    try {
      await api.contractorClaim(requestId, contractorEmail, contractorName);
      loadJobs();
    } catch(e: any) { Alert.alert('Error', e.message); }
  }

  async function submitFindings(requestId: string) {
    if (!findingsText || findingsText.length < 50) {
      Alert.alert('Too short', 'Please add detailed findings (at least 50 characters).');
      return;
    }
    try {
      await api.contractorSubmit(requestId, findingsText, contractorEmail);
      setFindingsOpen(null); setFindingsText('');
      loadJobs();
    } catch(e: any) { Alert.alert('Error', e.message); }
  }

  function logout() {
    AsyncStorage.removeItem('contractor_session');
    setScreen('login'); setCEmail(''); setCName('');
  }

  const filteredJobs = jobs.filter(j => {
    if (tab === 'open')      return j.status === 'OPEN';
    if (tab === 'mine')      return j.claimedBy === contractorEmail && ['CLAIMED','SUBMITTED','QA'].includes(j.status);
    return j.claimedBy === contractorEmail && ['SENT','PAID'].includes(j.status);
  });

  const totalEarned = jobs
    .filter(j => j.claimedBy === contractorEmail && j.status === 'PAID')
    .reduce((s, j) => s + (j.contractorPay || 0), 0);

  if (screen === 'login') return (
    <View style={styles.loginWrap}>
      <Text style={styles.logo}>Reward<Text style={{ color: C.teal }}>IQ</Text></Text>
      <Text style={styles.loginSub}>Contractor portal</Text>
      <Card style={{ marginTop: 24 }}>
        <Text style={styles.cardTitle}>Sign in</Text>
        <Text style={styles.cardSub}>Enter your contractor email to receive a login link.</Text>
        <TextInput style={styles.input} placeholder="you@email.com" placeholderTextColor={C.textHint} value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" />
        <ErrorBanner message={error} />
        <Button label={loading ? 'Sending...' : 'Send login link'} onPress={sendLink} loading={loading} />
      </Card>
    </View>
  );

  if (screen === 'sent') return (
    <View style={styles.loginWrap}>
      <Text style={styles.sentIcon}>📬</Text>
      <Text style={styles.cardTitle}>Check your inbox</Text>
      <Text style={styles.cardSub}>Login link sent to {email}. It expires in 15 minutes.</Text>
      <Button label="Use different email" onPress={() => setScreen('login')} variant="outline" style={{ marginTop: 16 }} />
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>Contractor Portal</Text>
          <Text style={styles.headerEmail}>{contractorEmail}</Text>
        </View>
        <Button label="Sign out" onPress={logout} variant="outline" style={{ paddingVertical: 7, paddingHorizontal: 12 }} />
      </View>

      {/* Stats */}
      <View style={styles.statsRow}>
        <View style={styles.statCard}><Text style={styles.statLabel}>Open jobs</Text><Text style={styles.statVal}>{jobs.filter(j => j.status === 'OPEN').length}</Text></View>
        <View style={styles.statCard}><Text style={styles.statLabel}>My active</Text><Text style={styles.statVal}>{jobs.filter(j => j.claimedBy === contractorEmail && ['CLAIMED','SUBMITTED'].includes(j.status)).length}</Text></View>
        <View style={[styles.statCard, { borderColor: C.tealMid }]}><Text style={styles.statLabel}>Total earned</Text><Text style={[styles.statVal, { color: C.tealDark }]}>${totalEarned.toLocaleString()}</Text></View>
      </View>

      {/* Tabs */}
      <View style={styles.tabs}>
        {(['open','mine','completed'] as const).map(t => (
          <TouchableOpacity key={t} style={[styles.tab, tab === t && styles.tabActive]} onPress={() => setTab(t)}>
            <Text style={[styles.tabText, tab === t && styles.tabTextActive]}>{t === 'open' ? 'Open jobs' : t === 'mine' ? 'My jobs' : 'Completed'}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView
        contentContainerStyle={{ padding: 14, paddingBottom: 40 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadJobs(); }} tintColor={C.teal} />}
      >
        {!filteredJobs.length ? (
          <EmptyState icon={tab === 'open' ? '🎯' : '📋'} title={tab === 'open' ? 'No open jobs' : 'No jobs here yet'} subtitle={tab === 'open' ? 'New requests come in daily.' : 'Claim an open job to get started.'} />
        ) : (
          filteredJobs.map(j => (
            <Card key={j.requestId} style={j.claimedBy === contractorEmail ? styles.claimedCard : undefined}>
              <View style={styles.jobHeader}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.jobId}>{j.requestId}</Text>
                  <Text style={styles.jobRoute}>{j.origin} → {j.destination}</Text>
                  <Text style={styles.jobMeta}>{j.departDate} · {j.cabin?.replace('_',' ')} · {j.passengers} pax</Text>
                </View>
                <View style={[styles.statusBadge, { backgroundColor: getStatusColor(j.status) + '25' }]}>
                  <Text style={[styles.statusText, { color: getStatusColor(j.status) }]}>{j.status}</Text>
                </View>
              </View>

              {j.notes ? <Text style={styles.jobNotes}>{j.notes}</Text> : null}

              {j.contractorPay ? <Text style={styles.jobPay}>Your pay: ${j.contractorPay}</Text> : null}

              <View style={styles.jobActions}>
                {j.status === 'OPEN' && (
                  <Button label="Claim this job" onPress={() => claimJob(j.requestId)} style={{ flex: 1 }} />
                )}
                {j.claimedBy === contractorEmail && j.status === 'CLAIMED' && (
                  <Button label={findingsOpen === j.requestId ? 'Cancel' : 'Submit findings'} onPress={() => { setFindingsOpen(findingsOpen === j.requestId ? null : j.requestId); setFindingsText(''); }} variant="outline" style={{ flex: 1 }} />
                )}
                {['SUBMITTED','QA'].includes(j.status) && j.claimedBy === contractorEmail && (
                  <View style={styles.submittedNotice}>
                    <Text style={styles.submittedText}>Findings submitted — under review</Text>
                  </View>
                )}
              </View>

              {findingsOpen === j.requestId && (
                <View style={styles.findingsPanel}>
                  <Text style={styles.findingsLabel}>Research findings</Text>
                  <Text style={styles.findingsHint}>Include: airline, flight number, award cost, transfer path, booking steps.</Text>
                  <TextInput
                    style={styles.findingsInput}
                    multiline
                    placeholder="e.g. Found ANA business JFK→NRT via United partner award..."
                    placeholderTextColor={C.textHint}
                    value={findingsText}
                    onChangeText={setFindingsText}
                  />
                  <Button label="Submit findings" onPress={() => submitFindings(j.requestId)} style={{ marginTop: 8 }} />
                </View>
              )}
            </Card>
          ))
        )}
      </ScrollView>
    </View>
  );
}

function getStatusColor(status: string) {
  const colors: Record<string,string> = { OPEN: '#F59E0B', CLAIMED: C.teal, SUBMITTED: '#8B5CF6', QA: '#3B82F6', SENT: '#10B981', PAID: '#059669' };
  return colors[status] || C.textHint;
}

const styles = StyleSheet.create({
  loginWrap: { flex: 1, justifyContent: 'center', padding: 24, backgroundColor: C.bg },
  logo: { fontSize: 32, fontWeight: '700', color: C.text, textAlign: 'center' },
  loginSub: { fontSize: 14, color: C.textMuted, textAlign: 'center', marginTop: 4, marginBottom: 8 },
  cardTitle: { fontSize: 18, fontWeight: '600', color: C.text, marginBottom: 6 },
  cardSub: { fontSize: 13, color: C.textMuted, marginBottom: 16, lineHeight: 19 },
  sentIcon: { fontSize: 48, textAlign: 'center', marginBottom: 12 },
  input: { backgroundColor: C.bg, borderWidth: 0.5, borderColor: C.borderStrong, borderRadius: 8, paddingHorizontal: 14, paddingVertical: 11, fontSize: 14, color: C.text, marginBottom: 12 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 56, paddingHorizontal: 16, paddingBottom: 14, backgroundColor: C.bgCard, borderBottomWidth: 0.5, borderBottomColor: C.border },
  headerTitle: { fontSize: 18, fontWeight: '600', color: C.text },
  headerEmail: { fontSize: 12, color: C.textMuted },
  statsRow: { flexDirection: 'row', gap: 8, padding: 12, backgroundColor: C.bgCard, borderBottomWidth: 0.5, borderBottomColor: C.border },
  statCard: { flex: 1, backgroundColor: C.bgSurface, borderRadius: 8, padding: 10, borderWidth: 0.5, borderColor: C.border },
  statLabel: { fontSize: 10, textTransform: 'uppercase', letterSpacing: 0.8, color: C.textHint },
  statVal: { fontSize: 22, fontWeight: '700', color: C.text },
  tabs: { flexDirection: 'row', backgroundColor: C.bgCard, borderBottomWidth: 0.5, borderBottomColor: C.border },
  tab: { flex: 1, paddingVertical: 12, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabActive: { borderBottomColor: C.teal },
  tabText: { fontSize: 13, color: C.textMuted },
  tabTextActive: { color: C.tealDark, fontWeight: '500' },
  claimedCard: { borderLeftWidth: 3, borderLeftColor: C.teal },
  jobHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 },
  jobId: { fontSize: 10, color: C.textHint, fontFamily: 'monospace', marginBottom: 2 },
  jobRoute: { fontSize: 15, fontWeight: '600', color: C.text },
  jobMeta: { fontSize: 12, color: C.textMuted, marginTop: 2 },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 100 },
  statusText: { fontSize: 11, fontWeight: '500' },
  jobNotes: { fontSize: 12, color: C.textMuted, backgroundColor: C.bgSurface, borderRadius: 6, padding: 8, marginTop: 6 },
  jobPay: { fontSize: 13, fontWeight: '600', color: C.tealDark, marginTop: 6 },
  jobActions: { marginTop: 10, flexDirection: 'row', gap: 8 },
  submittedNotice: { flex: 1, backgroundColor: '#EDE9FE', borderRadius: 8, padding: 10 },
  submittedText: { fontSize: 12, color: '#5B21B6', textAlign: 'center' },
  findingsPanel: { marginTop: 12, paddingTop: 12, borderTopWidth: 0.5, borderTopColor: C.border },
  findingsLabel: { fontSize: 13, fontWeight: '500', color: C.text, marginBottom: 4 },
  findingsHint: { fontSize: 11, color: C.textHint, marginBottom: 8, lineHeight: 16 },
  findingsInput: { backgroundColor: C.bg, borderWidth: 0.5, borderColor: C.borderStrong, borderRadius: 8, padding: 12, fontSize: 13, color: C.text, minHeight: 120, textAlignVertical: 'top' },
});
