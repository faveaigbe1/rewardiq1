export const APPS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbw3pC2sF0Icxyf1RG7MYt3WbKevMU9CH67-zCI9VO1sKEgisoBgftru395AJ7d0OHN7yQ/exec';
export const STRIPE_REPORT_LINK = 'https://buy.stripe.com/test_cNi6oHgDsh1D7ZfgG59MY00';
export const STRIPE_TRIP_LINK   = 'https://buy.stripe.com/placeholder';
export const BOOKING_URL        = 'https://calendar.app.google/JVfxUu2EsV9E1g2q8';
export const ADMIN_EMAIL        = 'geraldnoria@gmail.com';
export const REPORT_PRICE       = '$49';

export const SPEND_OPTIONS = [
  { label: 'Under $10,000/month',      value: '5000'   },
  { label: '$10,000 – $30,000/month',  value: '20000'  },
  { label: '$30,000 – $60,000/month',  value: '45000'  },
  { label: '$60,000 – $100,000/month', value: '80000'  },
  { label: 'Over $100,000/month',      value: '150000' },
];

export const CATEGORIES = [
  { value: 'advertising', label: 'Advertising',        icon: '📢' },
  { value: 'supplies',    label: 'Supplies/inventory', icon: '📦' },
  { value: 'travel',      label: 'Travel',             icon: '✈️' },
  { value: 'fuel',        label: 'Fuel/fleet',         icon: '⛽' },
  { value: 'software',    label: 'Software/SaaS',      icon: '💻' },
  { value: 'dining',      label: 'Dining',             icon: '🍽️' },
  { value: 'shipping',    label: 'Shipping',           icon: '🚚' },
  { value: 'other',       label: 'General/other',      icon: '📋' },
];

export const GOALS = [
  { value: 'business_class', label: 'Business class', icon: '🛫' },
  { value: 'luxury_hotels',  label: 'Luxury hotels',  icon: '🏨' },
  { value: 'cash_back',      label: 'Cash back',      icon: '💵' },
  { value: 'family_travel',  label: 'Family trips',   icon: '👨‍👩‍👧' },
  { value: 'flexibility',    label: 'Max flexibility', icon: '🎯' },
  { value: 'not_sure',       label: 'Not sure yet',   icon: '🔍' },
];

export const SEGMENT_COLORS: Record<string, { bg: string; text: string }> = {
  PLATINUM: { bg: '#F3F0FF', text: '#5B21B6' },
  GOLD:     { bg: '#FAEEDA', text: '#854F0B' },
  SILVER:   { bg: '#F5F4F1', text: '#6b7280' },
  BRONZE:   { bg: '#FEF3C7', text: '#92400E' },
};
