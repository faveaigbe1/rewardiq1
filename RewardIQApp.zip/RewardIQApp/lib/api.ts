import { APPS_SCRIPT_URL } from './constants';

async function callAppsScript(payload: object): Promise<any> {
  const encoded = encodeURIComponent(JSON.stringify(payload));
  const res = await fetch(`${APPS_SCRIPT_URL}?data=${encoded}`);
  const data = await res.json();
  if (data.error) throw new Error(data.error);
  return data;
}

export const api = {
  analyze: (params: {
    spendAmount: string;
    categories: string[];
    currentCard: string;
    goal: string;
    email: string;
  }) => callAppsScript({ action: 'analyze', ...params }),

  segment: (params: {
    email: string;
    spendAmount: string;
    employees: string;
    style: string;
    urgency: string;
    paidBefore: string;
    travel: string;
  }) => callAppsScript({ action: 'segment', ...params }),

  sendReport: (email: string) =>
    callAppsScript({ action: 'send_report', email }),

  tripRequest: (params: object) =>
    callAppsScript({ action: 'trip_request', ...params }),

  adminData: () =>
    callAppsScript({ action: 'admin_data' }),

  contractorLogin: (email: string) =>
    callAppsScript({ action: 'contractor_login', email }),

  contractorVerify: (token: string, email: string) =>
    callAppsScript({ action: 'contractor_verify', token, email }),

  contractorJobs: (email: string) =>
    callAppsScript({ action: 'contractor_jobs', email }),

  contractorClaim: (requestId: string, email: string, name: string) =>
    callAppsScript({ action: 'contractor_claim', requestId, email, name }),

  contractorSubmit: (requestId: string, findings: string, email: string) =>
    callAppsScript({ action: 'contractor_submit', requestId, findings, email }),
};
