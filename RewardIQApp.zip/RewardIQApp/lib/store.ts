import { create } from 'zustand';

interface AnalysisState {
  spendAmount:  string;
  categories:   string[];
  currentCard:  string;
  goal:         string;
  email:        string;
  analysis:     any | null;
  psycho: {
    employees:  string;
    style:      string;
    urgency:    string;
    paidBefore: string;
    travel:     string;
  };
  setSpend:      (v: string) => void;
  toggleCat:     (v: string) => void;
  setCard:       (v: string) => void;
  setGoal:       (v: string) => void;
  setEmail:      (v: string) => void;
  setAnalysis:   (a: any) => void;
  setPsycho:     (k: string, v: string) => void;
  reset:         () => void;
}

const defaultPsycho = { employees: '', style: '', urgency: '', paidBefore: '', travel: '' };

export const useAnalysisStore = create<AnalysisState>((set) => ({
  spendAmount: '',
  categories:  [],
  currentCard: '',
  goal:        '',
  email:       '',
  analysis:    null,
  psycho:      defaultPsycho,

  setSpend:    (v) => set({ spendAmount: v }),
  toggleCat:   (v) => set((s) => ({
    categories: s.categories.includes(v)
      ? s.categories.filter((c) => c !== v)
      : [...s.categories, v],
  })),
  setCard:     (v) => set({ currentCard: v }),
  setGoal:     (v) => set({ goal: v }),
  setEmail:    (v) => set({ email: v }),
  setAnalysis: (a) => set({ analysis: a }),
  setPsycho:   (k, v) => set((s) => ({ psycho: { ...s.psycho, [k]: v } })),
  reset:       () => set({ spendAmount: '', categories: [], currentCard: '', goal: '', email: '', analysis: null, psycho: defaultPsycho }),
}));
