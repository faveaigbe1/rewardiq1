import React from 'react';
import {
  View, Text, TouchableOpacity, TextInput,
  ActivityIndicator, ScrollView, StyleSheet,
} from 'react-native';

// ── Colors ───────────────────────────────────────────────────
export const C = {
  teal:        '#1D9E75',
  tealDark:    '#0F6E56',
  tealDarker:  '#085041',
  tealLight:   '#E1F5EE',
  tealMid:     '#5DCAA5',
  text:        '#1a1a1a',
  textMuted:   '#6b7280',
  textHint:    '#9ca3af',
  bg:          '#fafaf9',
  bgCard:      '#ffffff',
  bgSurface:   '#f5f4f1',
  border:      'rgba(0,0,0,0.09)',
  borderStrong:'rgba(0,0,0,0.18)',
  redLight:    '#FCEBEB',
  redBorder:   '#F09595',
  redText:     '#A32D2D',
  amberLight:  '#FAEEDA',
  amberDark:   '#854F0B',
  amberBorder: '#FAC775',
  greenLight:  '#DCFCE7',
  greenText:   '#166534',
};

// ── Card ─────────────────────────────────────────────────────
export function Card({ children, style }: { children: React.ReactNode; style?: any }) {
  return (
    <View style={[styles.card, style]}>
      {children}
    </View>
  );
}

// ── Section title ─────────────────────────────────────────────
export function SectionTitle({ children }: { children: string }) {
  return <Text style={styles.sectionTitle}>{children}</Text>;
}

// ── Primary button ────────────────────────────────────────────
export function Button({
  label, onPress, disabled, loading, variant = 'primary', style
}: {
  label: string;
  onPress: () => void;
  disabled?: boolean;
  loading?: boolean;
  variant?: 'primary' | 'outline' | 'ghost';
  style?: any;
}) {
  const btnStyle = [
    styles.btn,
    variant === 'primary' && styles.btnPrimary,
    variant === 'outline' && styles.btnOutline,
    variant === 'ghost'   && styles.btnGhost,
    (disabled || loading) && styles.btnDisabled,
    style,
  ];
  const txtStyle = [
    styles.btnText,
    variant === 'outline' && styles.btnTextOutline,
    variant === 'ghost'   && styles.btnTextGhost,
  ];
  return (
    <TouchableOpacity style={btnStyle} onPress={onPress} disabled={disabled || loading} activeOpacity={0.8}>
      {loading
        ? <ActivityIndicator color={variant === 'primary' ? '#fff' : C.teal} size="small" />
        : <Text style={txtStyle}>{label}</Text>
      }
    </TouchableOpacity>
  );
}

// ── Input ─────────────────────────────────────────────────────
export function Input({
  label, hint, placeholder, value, onChangeText, multiline, keyboardType, autoCapitalize
}: {
  label?: string;
  hint?: string;
  placeholder?: string;
  value: string;
  onChangeText: (v: string) => void;
  multiline?: boolean;
  keyboardType?: any;
  autoCapitalize?: any;
}) {
  return (
    <View style={styles.fieldGroup}>
      {label && <Text style={styles.fieldLabel}>{label}</Text>}
      {hint  && <Text style={styles.fieldHint}>{hint}</Text>}
      <TextInput
        style={[styles.input, multiline && styles.inputMulti]}
        placeholder={placeholder}
        placeholderTextColor={C.textHint}
        value={value}
        onChangeText={onChangeText}
        multiline={multiline}
        keyboardType={keyboardType}
        autoCapitalize={autoCapitalize || 'none'}
        autoCorrect={false}
      />
    </View>
  );
}

// ── Select chip ───────────────────────────────────────────────
export function Chip({
  label, icon, selected, onPress
}: {
  label: string; icon?: string; selected: boolean; onPress: () => void;
}) {
  return (
    <TouchableOpacity
      style={[styles.chip, selected && styles.chipSelected]}
      onPress={onPress}
      activeOpacity={0.7}
    >
      {icon && <Text style={styles.chipIcon}>{icon}</Text>}
      <Text style={[styles.chipLabel, selected && styles.chipLabelSelected]}>{label}</Text>
    </TouchableOpacity>
  );
}

// ── Badge ─────────────────────────────────────────────────────
export function Badge({ label, color = C.teal, bg = C.tealLight }: { label: string; color?: string; bg?: string }) {
  return (
    <View style={[styles.badge, { backgroundColor: bg, borderColor: color + '40' }]}>
      <Text style={[styles.badgeText, { color }]}>{label}</Text>
    </View>
  );
}

// ── Eyebrow label ─────────────────────────────────────────────
export function Eyebrow({ children }: { children: string }) {
  return <Text style={styles.eyebrow}>{children}</Text>;
}

// ── Loading screen ────────────────────────────────────────────
export function LoadingScreen({ message }: { message?: string }) {
  return (
    <View style={styles.loadingWrap}>
      <ActivityIndicator size="large" color={C.teal} />
      {message && <Text style={styles.loadingText}>{message}</Text>}
    </View>
  );
}

// ── Empty state ───────────────────────────────────────────────
export function EmptyState({
  icon, title, subtitle, action, onAction
}: {
  icon: string; title: string; subtitle?: string; action?: string; onAction?: () => void;
}) {
  return (
    <View style={styles.emptyWrap}>
      <Text style={styles.emptyIcon}>{icon}</Text>
      <Text style={styles.emptyTitle}>{title}</Text>
      {subtitle && <Text style={styles.emptySub}>{subtitle}</Text>}
      {action && onAction && (
        <Button label={action} onPress={onAction} style={{ marginTop: 16 }} />
      )}
    </View>
  );
}

// ── Error banner ──────────────────────────────────────────────
export function ErrorBanner({ message }: { message: string }) {
  if (!message) return null;
  return (
    <View style={styles.errorBanner}>
      <Text style={styles.errorText}>⚠️ {message}</Text>
    </View>
  );
}

// ── Stat card ─────────────────────────────────────────────────
export function StatCard({ label, value, green }: { label: string; value: string; green?: boolean }) {
  return (
    <View style={styles.statCard}>
      <Text style={styles.statLabel}>{label}</Text>
      <Text style={[styles.statVal, green && { color: C.tealDark }]}>{value}</Text>
    </View>
  );
}

// ── Styles ────────────────────────────────────────────────────
const styles = StyleSheet.create({
  card: {
    backgroundColor: C.bgCard,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 0.5,
    borderColor: C.border,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 11,
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    color: C.textHint,
    fontWeight: '500',
    marginBottom: 8,
    marginTop: 4,
  },
  btn: {
    paddingVertical: 14,
    paddingHorizontal: 24,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
  },
  btnPrimary:  { backgroundColor: C.teal },
  btnOutline:  { backgroundColor: 'transparent', borderWidth: 0.5, borderColor: C.borderStrong },
  btnGhost:    { backgroundColor: 'transparent' },
  btnDisabled: { opacity: 0.5 },
  btnText:     { color: '#fff', fontSize: 15, fontWeight: '500' },
  btnTextOutline: { color: C.textMuted },
  btnTextGhost:   { color: C.teal },
  fieldGroup:  { marginBottom: 16 },
  fieldLabel:  { fontSize: 13, fontWeight: '500', color: C.text, marginBottom: 6 },
  fieldHint:   { fontSize: 12, color: C.textHint, marginBottom: 6 },
  input: {
    backgroundColor: C.bg,
    borderWidth: 0.5,
    borderColor: C.borderStrong,
    borderRadius: 8,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 14,
    color: C.text,
  },
  inputMulti: { minHeight: 90, textAlignVertical: 'top', paddingTop: 10 },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 10,
    borderWidth: 0.5,
    borderColor: C.borderStrong,
    borderRadius: 8,
    backgroundColor: C.bg,
  },
  chipSelected: { borderColor: C.teal, backgroundColor: C.tealLight },
  chipIcon:  { fontSize: 16 },
  chipLabel: { fontSize: 13, color: C.text },
  chipLabelSelected: { color: C.tealDark, fontWeight: '500' },
  badge: {
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 100,
    borderWidth: 0.5,
    alignSelf: 'flex-start',
  },
  badgeText: { fontSize: 11, fontWeight: '600' },
  eyebrow: {
    fontSize: 11,
    letterSpacing: 1,
    textTransform: 'uppercase',
    color: C.tealDark,
    fontWeight: '500',
  },
  loadingWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  loadingText: { fontSize: 14, color: C.textMuted, marginTop: 8 },
  emptyWrap:   { alignItems: 'center', padding: 32, backgroundColor: C.bgSurface, borderRadius: 12 },
  emptyIcon:   { fontSize: 32, marginBottom: 8 },
  emptyTitle:  { fontSize: 15, fontWeight: '500', color: C.textMuted, marginBottom: 4, textAlign: 'center' },
  emptySub:    { fontSize: 13, color: C.textHint, textAlign: 'center' },
  errorBanner: { backgroundColor: '#FCEBEB', borderRadius: 8, padding: 12, marginBottom: 12, borderWidth: 0.5, borderColor: '#F09595' },
  errorText:   { fontSize: 13, color: '#A32D2D' },
  statCard:    { backgroundColor: C.bgCard, borderRadius: 8, padding: 14, borderWidth: 0.5, borderColor: C.border, flex: 1 },
  statLabel:   { fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.8, color: C.textHint, marginBottom: 4 },
  statVal:     { fontSize: 24, fontWeight: '700', color: C.text },
});
