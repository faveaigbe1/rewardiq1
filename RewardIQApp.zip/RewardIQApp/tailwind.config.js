/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,jsx,ts,tsx}', './components/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        teal: {
          DEFAULT: '#1D9E75',
          dark: '#0F6E56',
          darker: '#085041',
          light: '#E1F5EE',
          mid: '#5DCAA5',
        },
        amber: {
          light: '#FAEEDA',
          dark: '#854F0B',
          border: '#FAC775',
        }
      },
      fontFamily: {
        sans: ['DMSans_400Regular'],
        'sans-medium': ['DMSans_500Medium'],
        serif: ['DMSerifDisplay_400Regular'],
        'serif-italic': ['DMSerifDisplay_400Regular_Italic'],
      }
    },
  },
  plugins: [],
};
